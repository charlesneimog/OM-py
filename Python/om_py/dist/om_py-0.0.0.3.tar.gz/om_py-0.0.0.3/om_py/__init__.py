# python setup.py sdist bdist_wheel

from om_py.functions import f2mc
from om_py.random import Random 
from om_py.python_to_om import to_om

