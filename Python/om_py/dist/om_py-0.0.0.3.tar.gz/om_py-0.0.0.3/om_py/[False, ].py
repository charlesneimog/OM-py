[False, ]

((nil) (nil) (1) (2) (nil) (nil) (3) (4) (nil) (nil) (5) (nil) (nil) (6) (7) (8))